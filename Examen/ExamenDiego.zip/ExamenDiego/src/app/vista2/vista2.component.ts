import { Component } from '@angular/core';

@Component({
  selector: 'app-vista2',
  standalone: true,
  imports: [Vista2Component],
  templateUrl: './vista2.component.html',
  styleUrl: './vista2.component.scss'
})
export class Vista2Component {

}
